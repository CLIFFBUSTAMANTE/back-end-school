/*

Create user:

sequelize model:create --name User --attributes  name:string,email:string,password:string,role:string

Create course:
sequelize model:create --name Course --attributes  name:string,description:string,userId:integer

Create Session
sequelize model:create --name Session --attributes  title:string,objective:string,courseId:integer

Create Session
sequelize model:create --name Resource --attributes  url:string,sessionId:integer,type:string

Create Evaluation
sequelize model:create --name Evaluation --attributes  name:string,userId:integer

Create Question
sequelize model:create --name Question --attributes  title:string,level:string,tags:string,evaluationId:integer

Create Answer
sequelize model:create --name Answer --attributes  description:string,questionId:integer,isAnswer:boolean

Create Result
sequelize model:create --name Result --attributes  name:string,userId:integer,evaluationId:integer,good:integer,bad:integer,points:integer

Create migration
sequelize migration:generate --name addColumnToQuestion      

sequelize db:migrate


Create Comp
sequelize model:create --name Comp --attributes  description:string

Create Des
sequelize model:create --name Des --attributes  description:string


*/