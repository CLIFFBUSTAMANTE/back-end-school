'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addColumn(
      'Results',
      'gooddesempeno',
      Sequelize.TEXT
    );
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeColumn(
      'Results',
      'gooddesempeno',
      Sequelize.TEXT
    );
  }
};
