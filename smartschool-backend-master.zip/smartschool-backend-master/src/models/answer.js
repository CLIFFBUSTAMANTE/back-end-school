'use strict';
module.exports = (sequelize, DataTypes) => {
  const Answer = sequelize.define('Answer', {
    description: DataTypes.STRING,
    questionId: DataTypes.INTEGER,
    isAnswer: DataTypes.BOOLEAN
  }, {});
  Answer.associate = function(models) {
    // associations can be defined here
    Answer.belongsTo(models.Question,{ foreignKey: 'questionId' });
  };
  return Answer;
};