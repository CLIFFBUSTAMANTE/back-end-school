'use strict';
module.exports = (sequelize, DataTypes) => {
  const Comp = sequelize.define('Comp', {
    description: DataTypes.STRING
  }, {});
  Comp.associate = function(models) {
    // associations can be defined here
  };
  return Comp;
};