'use strict';
module.exports = (sequelize, DataTypes) => {
  const Des = sequelize.define('Des', {
    description: DataTypes.STRING
  }, {});
  Des.associate = function(models) {
    // associations can be defined here
  };
  return Des;
};