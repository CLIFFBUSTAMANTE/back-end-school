'use strict';
module.exports = (sequelize, DataTypes) => {
  const Evaluation = sequelize.define('Evaluation', {
    name: DataTypes.STRING,
    userId: DataTypes.INTEGER,
    isEntrada: DataTypes.BOOLEAN,
    sessionId: DataTypes.INTEGER
  }, {});
  Evaluation.associate = function(models) {
    // associations can be defined here
  };
  return Evaluation;
};