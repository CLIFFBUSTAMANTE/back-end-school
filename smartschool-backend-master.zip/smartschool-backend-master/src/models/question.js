'use strict';
module.exports = (sequelize, DataTypes) => {
  const Question = sequelize.define('Question', {
    title: DataTypes.STRING,
    level: DataTypes.STRING,
    tags: DataTypes.STRING,
    evaluationId: DataTypes.INTEGER,
    desId: DataTypes.INTEGER,
    compId: DataTypes.INTEGER,
    image: DataTypes.STRING,
    desempeno: DataTypes.TEXT,
    mejorar: DataTypes.TEXT,
  }, {});
  Question.associate = function(models) {
    // associations can be defined here
    Question.hasMany(models.Answer, { foreignKey: 'questionId' });

  };
  return Question;
};