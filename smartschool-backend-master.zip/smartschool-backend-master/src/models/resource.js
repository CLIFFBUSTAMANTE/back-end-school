'use strict';
module.exports = (sequelize, DataTypes) => {
  const Resource = sequelize.define('Resource', {
    url: DataTypes.STRING,
    sessionId: DataTypes.INTEGER,
    level: DataTypes.STRING,
    type: DataTypes.STRING,
    aditional: DataTypes.STRING,
    recomendations:DataTypes.STRING,

  }, {});
  Resource.associate = function(models) {
    // associations can be defined here
  };
  return Resource;
};