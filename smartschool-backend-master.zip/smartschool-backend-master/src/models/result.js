'use strict';
module.exports = (sequelize, DataTypes) => {
  const Result = sequelize.define('Result', {
    name: DataTypes.STRING,
    userId: DataTypes.INTEGER,
    evaluationId: DataTypes.INTEGER,
    good: DataTypes.INTEGER,
    bad: DataTypes.INTEGER,
    points: DataTypes.INTEGER,
    baddesempeno:DataTypes.TEXT,
    gooddesempeno:DataTypes.TEXT,
  }, {});
  Result.associate = function(models) {
    // associations can be defined here
  };
  return Result;
};