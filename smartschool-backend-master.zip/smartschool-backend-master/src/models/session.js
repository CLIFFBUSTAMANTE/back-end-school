'use strict';
module.exports = (sequelize, DataTypes) => {
  const Session = sequelize.define('Session', {
    title: DataTypes.STRING,
    objective: DataTypes.STRING,
    courseId: DataTypes.INTEGER
  }, {});
  Session.associate = function(models) {
    // associations can be defined here
  };
  return Session;
};