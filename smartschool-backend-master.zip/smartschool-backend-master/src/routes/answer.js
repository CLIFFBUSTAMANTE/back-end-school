const express = require('express');
const router = express.Router();
const Answer = require("../models").Answer;


router.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});


router.get('/answer', async (req,res)=>{

    const answers = await Answer.findAll()
    return res.json({
      ok: true,
      answers
    })
});
router.post('/answer', async (req,res)=>{
  
    const { 
        description,
        questionId,
        isAnswer,
      } = req.body;
    if ( !description || !questionId || isAnswer == null ){
        return res.json({
          ok: false,
          error: "Ingrese todos los datos",
        })
    }
    const answer = await Answer.create({
        description,
        questionId,
        isAnswer,
    })

  return res.json({
    ok: true,
    answer,
  })
});

module.exports = router;
