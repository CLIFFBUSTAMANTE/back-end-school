const express = require('express');
const router = express.Router();
const Course = require("../models").Course;


router.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});


router.get('/course', async (req,res)=>{

    const courses = await Course.findAll()
    return res.json({
      ok: true,
      courses
    })
});
router.post('/course', async (req,res)=>{
  
    const { 
        name,
        description,
        userId,
      } = req.body;
    if ( !name || !description || !userId ){
        return res.json({
          ok: false,
          error: "Ingrese todos los datos"
        })
    }
    const course = await Course.create({
        name,
        description,
        userId,
    })

  return res.json({
    ok: true,
    course,
  })
});

module.exports = router;
