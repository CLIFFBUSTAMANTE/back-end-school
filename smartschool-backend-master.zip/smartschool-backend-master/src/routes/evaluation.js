const express = require('express');
const router = express.Router();
const Evaluation = require("../models").Evaluation;
const Question = require("../models").Question;
const Answer = require("../models").Answer;

router.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

router.get('/evaluation/:id/entrada', async (req,res)=>{
    const{ id } = req.params;
    const evaluation = await Evaluation.findOne({
        where:{ 
            sessionId:id,
            isEntrada: true
        },
    })
    if ( evaluation && evaluation.id ) {
        const questions = await Question.findAll({
            where:{ 
                evaluationId:evaluation.id,
            },
            include: [
                { model: Answer },
            ]
        })

        return res.json({
            ok: true,
            evaluation,
            questions
          })
    } else {
        return res.json({
            ok: false,
            evaluation,
            questions: []
          })
    }
});
router.get('/evaluation/:id/salida', async (req,res)=>{
    const{ id } = req.params;
    const evaluation = await Evaluation.findOne({
        where:{ 
            sessionId:id,
            isEntrada: false
        },
    })
    if ( evaluation && evaluation.id ) {
        const questions = await Question.findAll({
            where:{ 
                evaluationId:evaluation.id,
            },
            include: [
                { model: Answer },
            ]
        })
        return res.json({
            ok: true,
            evaluation,
            questions
          })
    } else {
        return res.json({
            ok: false,
            evaluation,
            questions: []
          })
    }
});
router.get('/evaluation', async (req,res)=>{

    const evaluations = await Evaluation.findAll()
    return res.json({
      ok: true,
      evaluations
    })
});




router.post('/evaluation', async (req,res)=>{
  
    const { 
        name,
        userId,
        isEntrada,
        sessionId,
      } = req.body;
    if ( !userId || isEntrada == null || !sessionId ){
        return res.json({
          ok: false,
          error: "Ingrese todos los datos",
          
        })
    }
    const evaluation = await Evaluation.create({
        name,
        userId,
        isEntrada,
        sessionId
    })

  return res.json({
    ok: true,
    evaluation,
  })
});

module.exports = router;
