const express = require('express');
const router = express.Router();


router.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

router.use(require('./users'));
router.use(require('./session'));
router.use(require('./question'));
router.use(require('./course'));
router.use(require('./resource'));
router.use(require('./evaluation'));
router.use(require('./answer'));
router.use(require('./result'));

router.get('/',(req,res)=>{

    res.json({
      ok: true,
      message: "El API funciona xd"
    })
});

module.exports = router;