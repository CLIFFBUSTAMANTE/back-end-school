const express = require('express');
const router = express.Router();
const Question = require("../models").Question;
const Answer = require("../models").Answer;


router.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});


router.get('/questions', async (req,res)=>{

    const questions = await Question.findAll()
    return res.json({
      ok: true,
      questions
    })
});



router.post('/questionanswer', async (req,res)=>{
  
  const { 
    title,
    level,
    tags,
    evaluationId,
    desId,
    compId,
    image,
    respuestas,
    desempeno,
    mejorar
    } = req.body;
  if ( !title || !level || !evaluationId || !desId || !compId ){
      return res.json({
        ok: false,
        error: "Ingrese todos los datos",
      })
  }
  const question = await Question.create({
    title,
    level,
    tags,
    evaluationId,
    desId,
    compId,
    image,
    desempeno,
    mejorar
  })
  for (let index = 0; index < respuestas.length; index++) {
    const element = respuestas[index];
      const answer = await Answer.create({
          description: element.description,
          questionId: question.id,
          isAnswer: element.isAnswer,
      })
  }
  const questions = await Question.findAll({
    where:{ 
        evaluationId:evaluationId,
    },
    include: [
        { model: Answer },
    ]
})

return res.json({
  ok: true,
  questions,
})
});

router.post('/questions', async (req,res)=>{
  
  const { 
    title,
    level,
    tags,
    evaluationId,
    desId,
    compId,
    image,
    desempeno,
    mejorar
    } = req.body;
  if ( !title || !level || !evaluationId || !desId || !compId ){
      return res.json({
        ok: false,
        error: "Ingrese todos los datos",
      })
  }
  const question = await Question.create({
    title,
    level,
    tags,
    evaluationId,
    desId,
    compId,
    image,
    desempeno,
    mejorar
  })

return res.json({
  ok: true,
  question,
})
});


router.post('/deletequestions', async (req,res)=>{

  const { 
      id,
      evaluationId
    } = req.body;

    if ( !id || !evaluationId ){
      return res.json({
        ok: false,
        questions: [],
      })
    }
  await Answer.destroy({
    where: {
      questionId: id
    }
  });
  await Question.destroy({
    where: {
      id: id
    }
  });

const questions = await Question.findAll({
    where:{ 
        evaluationId:evaluationId,
    },
    include: [
        { model: Answer },
    ]
})

return res.json({
  ok: true,
  questions,
})


});


module.exports = router;
