const express = require('express');
const router = express.Router();
const Resource = require("../models").Resource;
const Session = require("../models").Session;


router.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});


router.get('/resource', async (req,res)=>{

    const resource = await Resource.findAll()
    return res.json({
      ok: true,
      resource
    })
});

router.get('/resource/:id', async (req,res)=>{
    const{ id } = req.params;

    const sessions = await Session.findOne({
        where:{ 
            id:id,
        },
    })
    const resourceBasico = await Resource.findAll({
        where:{ 
            sessionId:id, level: "basico"
        },
    })
    const resourceIntermedio = await Resource.findAll({
        where:{ 
            sessionId:id, level: "intermedio"
        },
    })
    const resourceAvanzado = await Resource.findAll({
        where:{ 
            sessionId:id, level: "avanzado"
        },
    })

    return res.json({
      ok: true,
      sessions,
      resourceBasico,
      resourceIntermedio,
      resourceAvanzado
    })
});

router.post('/resource', async (req,res)=>{
  
    const { 
        url,
        sessionId,
        type,
        level,
        aditional,
        recomendations,
      } = req.body;
    if ( !url || !sessionId || !type || !level ){
        return res.json({
          ok: false,
          error: "Ingrese todos los datos"
        })
    }
    const resource = await Resource.create({
        url,
        sessionId,
        type,
        level,
        aditional,
        recomendations,
    })

    const resourceBasico = await Resource.findAll({
        where:{ 
            sessionId:sessionId, level: "basico"
        },
    })
    const resourceIntermedio = await Resource.findAll({
        where:{ 
            sessionId:sessionId, level: "intermedio"
        },
    })
    const resourceAvanzado = await Resource.findAll({
        where:{ 
            sessionId:sessionId, level: "avanzado"
        },
    })

    return res.json({
      ok: true,
      resourceBasico,
      resourceIntermedio,
      resourceAvanzado
    })
});

module.exports = router;
