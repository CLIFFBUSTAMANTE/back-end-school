const express = require('express');
const router = express.Router();
const Result = require("../models").Result;
const Evaluation = require("../models").Evaluation;
const Sequelize = require('sequelize');


router.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});


router.get('/result', async (req,res)=>{

    const result = await Result.findAll()
    return res.json({
      ok: true,
      result
    })
});

router.get('/result/:id', async (req,res)=>{

    const { id } = req.params
    const results = await Result.findAll({
        where: {
            userId: id
        }
    })
    return res.json({
      ok: true,
      results
    })
});
router.get('/resultbysesion/:id', async (req,res)=>{

    const { id } = req.params
    const evaluations = await Evaluation.findAll({
        where:{
            sessionId: id
        }
    })
    const Op = Sequelize.Op;
    let arrayevaluation = []
    evaluations.forEach(e => {
        arrayevaluation.push( e.id )
    });

    const results = await Result.findAll({
        where: {
            evaluationId: {
                [Op.in]: arrayevaluation
              }
        }
    })
    return res.json({
      ok: true,
      evaluations,
      results
    })
});
router.get('/resultbyevaluation/:id', async (req,res)=>{

    const { id } = req.params
    const results = await Result.findAll({
        where: {
            evaluationId: id
        }
    })
    return res.json({
      ok: true,
      results
    })
});
router.post('/result', async (req,res)=>{

    const {
        userId,
        evaluationId,
        name,
        good,
        bad,
        points,
        baddesempeno,
        gooddesempeno,
    
    } = req.body

    const results = await Result.create({
        userId,
        evaluationId,
        name,
        good,
        bad,
        points,
        baddesempeno,
        gooddesempeno,
    })

    return res.json({
      ok: true,
      results
    })
});

module.exports = router;
