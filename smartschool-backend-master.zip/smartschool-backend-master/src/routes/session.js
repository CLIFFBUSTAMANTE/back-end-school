const express = require('express');
const router = express.Router();
const Session = require("../models").Session;
const Course = require("../models").Course;
const Evaluation = require("../models").Evaluation;


router.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});


router.get('/session', async (req,res)=>{

    const sessions = await Session.findAll()
    return res.json({
      ok: true,
      sessions
    })
});


router.get('/session/:id', async (req,res)=>{
  const{ id } = req.params;

  const course = await Course.findOne({
      where:{ 
          id:id,
      },
  })
  const sessions = await Session.findAll({
      where:{ 
        courseId:id
      },
  })

  return res.json({
    ok: true,
    course,
    sessions,
  })
});
router.post('/session', async (req,res)=>{
  
    const { 
        title,
        objective,
        courseId,
      } = req.body;
    if ( !title || !objective || !courseId ){
        return res.json({
          ok: false,
          error: "Ingrese todos los datos"
        })
    }
    const session = await Session.create({
        title,
        objective,
        courseId,
    })
    const evaluationentrada = await Evaluation.create({
      name: `Evaluación de entrada de ${ session.title }`,
      userId: 1,
      isEntrada: true,
      sessionId: session.id
  })
  const evaluationasalida = await Evaluation.create({
    name: `Evaluación de salida de ${ session.title }`,
    userId: 1,
    isEntrada: false,
    sessionId: session.id
})
const sessions = await Session.findAll({
  where:{ 
    courseId:courseId
  },
})
  return res.json({
    ok: true,
    sessions,
  })
});

module.exports = router;
