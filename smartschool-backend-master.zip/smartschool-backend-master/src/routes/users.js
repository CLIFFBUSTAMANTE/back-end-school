const express = require('express');
const router = express.Router();
const Users = require("../models").User;


router.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});


router.get('/users', async (req,res)=>{


    const users = await Users.findAll()
    return res.json({
      ok: true,
      users
    })
});

router.post('/auth', async (req,res)=>{

  const { 
    email, 
    password, 
  } = req.body;
  if ( !email || !password ){
    return res.json({
      ok: false,
      error: "Ingrese todos los datos"
    })
  }
  const user = await Users.findOne({ 
    where: {
      email, 
      password, 
    }
  })
  if ( user ) {
    return res.json({
      ok: true,
      user
    })
  }
  return res.json({
    ok: false,
    user: {}
  })
});


router.post('/users', async (req,res)=>{

  const { 
    name,
    email, 
    password, 
    role,
  } = req.body;
  if ( !name || !email || !password || !role ){
    return res.json({
      ok: false,
      error: "Ingrese todos los datos"
    })
  }
  const user = await Users.create({ 
    name,
    email, 
    password, 
    role,
  })
  return res.json({
    ok: true,
    user
  })
});
router.put('/users', async (req,res)=>{

  const users = await Users.findAll()
  res.json({
    ok: true,
    message: "El API funciona xd",
    users
  })
});
router.delete('/users', async (req,res)=>{


  const users = await Users.findAll()
  res.json({
    ok: true,
    message: "El API funciona xd",
    users
  })
});
module.exports = router;
